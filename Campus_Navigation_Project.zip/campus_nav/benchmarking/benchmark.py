"""Measures BFS, DFS, Dijkstra and A* on the sample campus and synthetic campuses.
Run:  python benchmarking/benchmark.py     (writes CSV/JSON/PNG into results/)"""
import csv, itertools, json, statistics, sys, tracemalloc
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from algorithms import ALGORITHMS
from graph.data import generate_campus, load_campus, far_pair

OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
SIZES = (25, 100, 400, 900, 2500)      # requested number of locations
TRIALS = 7                             # different random campuses per size
REPEAT = 3                             # repeats per query; the fastest run is kept
COLORS = {"BFS": "#2a78d6", "DFS": "#eb6834", "Dijkstra": "#1baf7a", "A*": "#e87ba4"}
MARKERS = {"BFS": "o", "DFS": "s", "Dijkstra": "^", "A*": "D"}


def best_of(fn, g, a, b):
    runs = [fn(g, a, b) for _ in range(REPEAT)]
    return min(runs, key=lambda r: r["time_ms"])


def run_sizes():
    rows = []
    for size in SIZES:
        for trial in range(TRIALS):
            g = generate_campus(size, seed=100 + trial)
            a, b = far_pair(g)
            for name, fn in ALGORITHMS:
                r = best_of(fn, g, a, b)
                rows.append(dict(size=size, locations=len(g.nodes), paths=g.edge_count(), trial=trial + 1,
                                 algorithm=name, time_ms=r["time_ms"], nodes_explored=r["nodes_explored"],
                                 max_frontier=r["max_frontier"], distance_m=r["cost"], hops=r["hops"]))
    return rows


def run_campus_all_pairs():
    g = load_campus()
    rows = []
    for name, fn in ALGORITHMS:
        rs = [fn(g, a, b) for a, b in itertools.permutations(g.nodes, 2)]
        rows.append(dict(algorithm=name, queries=len(rs),
                         avg_time_ms=statistics.mean(r["time_ms"] for r in rs),
                         avg_nodes_explored=statistics.mean(r["nodes_explored"] for r in rs),
                         avg_distance_m=statistics.mean(r["cost"] for r in rs),
                         avg_hops=statistics.mean(r["hops"] for r in rs)))
    return rows


def run_memory():
    rows = []
    for size in SIZES:
        g = generate_campus(size, seed=100)
        a, b = far_pair(g)
        for name, fn in ALGORITHMS:
            tracemalloc.start()
            fn(g, a, b)
            peak = tracemalloc.get_traced_memory()[1]
            tracemalloc.stop()
            rows.append(dict(size=size, locations=len(g.nodes), algorithm=name, peak_kb=peak / 1024))
    return rows


def write_csv(rows, name):
    with (OUT / name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)


def summarise(rows):
    out = []
    for size in SIZES:
        for name, _ in ALGORITHMS:
            s = [r for r in rows if r["size"] == size and r["algorithm"] == name]
            out.append(dict(size=size, locations=round(statistics.mean(r["locations"] for r in s)),
                            paths=round(statistics.mean(r["paths"] for r in s)), algorithm=name,
                            avg_time_ms=statistics.mean(r["time_ms"] for r in s),
                            avg_nodes_explored=statistics.mean(r["nodes_explored"] for r in s),
                            avg_max_frontier=statistics.mean(r["max_frontier"] for r in s),
                            avg_distance_m=statistics.mean(r["distance_m"] for r in s),
                            avg_hops=statistics.mean(r["hops"] for r in s)))
    return out


def chart(summary, key, ylabel, title, filename, logy=False, mem=None):
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.set_facecolor("#fcfcfb"); fig.patch.set_facecolor("#fcfcfb")
    data = mem or summary
    ends = []
    for i, (name, _) in enumerate(ALGORITHMS):
        pts = [s for s in data if s["algorithm"] == name]
        xs = [p["locations"] for p in pts]; ys = [p[key] for p in pts]
        ax.plot(xs, ys, marker=MARKERS[name], color=COLORS[name], lw=2, ms=12 - 2 * i, zorder=2 + i,
                markeredgecolor="#fcfcfb", markeredgewidth=1.5, label=name)
        ends.append((name, xs[-1], ys[-1]))
    span = (max(e[2] for e in ends) - min(e[2] for e in ends)) or 1
    placed = []                      # merge labels of lines that end (almost) on top of each other
    for name, x, y in sorted(ends, key=lambda e: e[2]):
        if placed and abs(placed[-1][2] - y) < 0.05 * span and not logy:
            placed[-1][0] += " = " + name
        else:
            placed.append([name, x, y])
    for name, x, y in placed:
        ax.annotate(name, (x, y), xytext=(10, 0), textcoords="offset points", va="center", fontsize=9, color="#3b3b38")
    ax.set_xscale("log")
    if logy: ax.set_yscale("log")
    ax.set_xlabel("Number of locations (log scale)", color="#3b3b38"); ax.set_ylabel(ylabel, color="#3b3b38")
    ax.set_title(title, loc="left", fontsize=12, color="#1a1a19")
    ax.grid(alpha=.25, lw=.6); ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.16))
    ax.margins(x=0.25)
    fig.tight_layout(); fig.savefig(OUT / filename, dpi=160); plt.close(fig)


def main():
    rows = run_sizes(); summary = summarise(rows); campus = run_campus_all_pairs(); mem = run_memory()
    write_csv(rows, "benchmark_results.csv"); write_csv(summary, "benchmark_summary.csv")
    write_csv(campus, "campus_all_pairs.csv"); write_csv(mem, "memory_results.csv")
    (OUT / "benchmark_summary.json").write_text(json.dumps(
        {"methodology": {"sizes": list(SIZES), "trials": TRIALS, "repeat_per_query": REPEAT,
                         "query": "far corner to far corner of each synthetic campus",
                         "note": "times are machine dependent"},
         "summary": summary, "campus_all_pairs": campus, "memory": mem}, indent=1))
    chart(summary, "avg_time_ms", "Average time (ms, log)", "Search time vs campus size", "performance_time.png", logy=True)
    chart(summary, "avg_nodes_explored", "Average locations explored", "Locations explored vs campus size", "performance_nodes.png")
    chart(summary, "avg_distance_m", "Average route length (m)", "Route length found vs campus size", "performance_distance.png")
    chart(summary, "peak_kb", "Peak memory (KB)", "Peak memory vs campus size", "performance_memory.png", mem=mem)
    print(f"{len(rows)} measurements, {len(summary)} summary rows written to {OUT}")


if __name__ == "__main__":
    main()
