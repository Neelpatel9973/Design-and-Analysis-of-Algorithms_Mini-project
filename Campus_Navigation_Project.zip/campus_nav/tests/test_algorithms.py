import itertools
import pytest
from graph.graph import CampusGraph
from graph.data import load_campus, generate_campus, build_scenario, far_pair, SYNTHETIC_SIZE
from algorithms import ALGORITHMS, bfs, dfs, dijkstra, astar


@pytest.fixture(scope="module")
def campus():
    return load_campus()


def floyd_warshall(g):
    """Slow but obviously-correct all-pairs shortest distances, used as the reference."""
    ids = list(g.nodes)
    d = {a: {b: (0 if a == b else float("inf")) for b in ids} for a in ids}
    for a in ids:
        for b, w in g.adjacency[a]:
            d[a][b] = min(d[a][b], w)
    for k in ids:
        for i in ids:
            for j in ids:
                if d[i][k] + d[k][j] < d[i][j]:
                    d[i][j] = d[i][k] + d[k][j]
    return d


def is_valid_path(g, path, start, goal):
    ok_ends = path[0] == start and path[-1] == goal
    ok_edges = all(any(n == b for n, _ in g.adjacency[a]) for a, b in zip(path, path[1:]))
    return ok_ends and ok_edges


def test_campus_loads(campus):
    assert len(campus.nodes) == 24 and campus.edge_count() == 41
    assert len(campus.largest_component()) == 24          # whole campus is connected


def test_all_algorithms_return_valid_paths(campus):
    for name, fn in ALGORITHMS:
        r = fn(campus, "GATE", "QUART")
        assert r["found"], name
        assert is_valid_path(campus, r["path"], "GATE", "QUART"), name
        assert r["cost"] == pytest.approx(campus.path_distance(r["path"]))


def test_dijkstra_matches_floyd_warshall_for_every_pair(campus):
    ref = floyd_warshall(campus)
    for a, b in itertools.permutations(campus.nodes, 2):
        assert dijkstra(campus, a, b)["cost"] == pytest.approx(ref[a][b]), (a, b)


def test_astar_matches_dijkstra_for_every_pair(campus):
    for a, b in itertools.permutations(campus.nodes, 2):
        assert astar(campus, a, b)["cost"] == pytest.approx(dijkstra(campus, a, b)["cost"]), (a, b)


def test_bfs_has_fewest_hops_and_dfs_never_beats_dijkstra(campus):
    for a, b in itertools.permutations(campus.nodes, 2):
        d, bf, df = dijkstra(campus, a, b), bfs(campus, a, b), dfs(campus, a, b)
        assert bf["hops"] <= d["hops"] and bf["hops"] <= df["hops"]
        assert d["cost"] <= bf["cost"] + 1e-9 and d["cost"] <= df["cost"] + 1e-9


def test_bfs_can_be_longer_in_distance_than_dijkstra(campus):
    # BFS minimises hops, not metres: on at least one pair it is strictly longer.
    assert any(bfs(campus, a, b)["cost"] > dijkstra(campus, a, b)["cost"] + 1e-9
               for a, b in itertools.permutations(campus.nodes, 2))


def test_astar_explores_no_more_than_dijkstra_on_average(campus):
    pairs = list(itertools.permutations(campus.nodes, 2))
    d = sum(dijkstra(campus, a, b)["nodes_explored"] for a, b in pairs)
    a_ = sum(astar(campus, a, b)["nodes_explored"] for a, b in pairs)
    assert a_ < d


def test_same_location(campus):
    for _, fn in ALGORITHMS:
        r = fn(campus, "LIB", "LIB")
        assert r["path"] == ["LIB"] and r["cost"] == 0 and r["hops"] == 0


def test_no_path_between_disconnected_locations():
    g = CampusGraph()
    for i, x in enumerate((0, 10, 500)):
        g.add_location(f"P{i}", f"P{i}", x, 0)
    g.add_path("P0", "P1", 10)                           # P2 is isolated
    for _, fn in ALGORITHMS:
        r = fn(g, "P0", "P2")
        assert not r["found"] and r["path"] == [] and r["cost"] is None


def test_path_shorter_than_straight_line_is_rejected():
    g = CampusGraph()
    g.add_location("A", "A", 0, 0); g.add_location("B", "B", 100, 0)
    with pytest.raises(ValueError):
        g.add_path("A", "B", 50)


def test_heuristic_is_admissible_and_consistent_on_every_edge(campus):
    for a, nbrs in campus.adjacency.items():
        for b, w in nbrs:
            assert campus.heuristic(a, b) <= w + 1e-9


@pytest.mark.parametrize("scenario", list(SYNTHETIC_SIZE))
def test_synthetic_graphs_are_connected_and_deterministic(scenario):
    g1, g2 = build_scenario(scenario, seed=5), build_scenario(scenario, seed=5)
    assert g1.to_dict() == g2.to_dict()
    assert len(g1.largest_component()) == len(g1.nodes)


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_all_algorithms_agree_on_synthetic_graph(seed):
    g = generate_campus(100, seed)
    a, b = far_pair(g)
    d, s = dijkstra(g, a, b), astar(g, a, b)
    assert d["cost"] == pytest.approx(s["cost"])
    assert bfs(g, a, b)["hops"] <= d["hops"]
    assert dfs(g, a, b)["found"]
