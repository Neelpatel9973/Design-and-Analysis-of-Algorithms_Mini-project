// Builds report/Campus_Navigation_Mini_Project_Report.docx from the real results in ../results
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, HeadingLevel, AlignmentType,
        WidthType, ShadingType, BorderStyle, LevelFormat, PageBreak, Footer, PageNumber } = require("docx");
const R = "../results/", S = "../screenshots/";
const csv = f => { const [h, ...rows] = fs.readFileSync(R + f, "utf8").trim().split("\n").map(l => l.trim().split(",")); return rows.map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); };
const summary = csv("benchmark_summary.csv"), campus = csv("campus_all_pairs.csv"), mem = csv("memory_results.csv");
const get = (size, alg) => summary.find(r => +r.size === size && r.algorithm === alg);
const f = (v, d = 2) => (+v).toFixed(d);
const pct = (a, b) => Math.round((1 - a / b) * 100);
const A25 = get(2500, "A*"), D25 = get(2500, "Dijkstra"), B25 = get(2500, "BFS"), F25 = get(2500, "DFS");
const A4 = get(400, "A*"), D4 = get(400, "Dijkstra");
const cA = campus.find(r => r.algorithm === "A*"), cD = campus.find(r => r.algorithm === "Dijkstra"), cB = campus.find(r => r.algorithm === "BFS"), cF = campus.find(r => r.algorithm === "DFS");

const W = 9026, bd = { style: BorderStyle.SINGLE, size: 4, color: "BFC7D1" }, borders = { top: bd, bottom: bd, left: bd, right: bd };
const P = (t, o = {}) => new Paragraph({ spacing: { after: 120, line: 276 }, ...o, children: Array.isArray(t) ? t : [new TextRun(t)] });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const B = t => new Paragraph({ numbering: { reference: "b", level: 0 }, spacing: { after: 60 }, children: [new TextRun(t)] });
const code = lines => lines.map(l => new Paragraph({ spacing: { after: 0 }, shading: { type: ShadingType.CLEAR, fill: "EEF2EC" }, children: [new TextRun({ text: l || " ", font: "Courier New", size: 19 })] }));
const gap = () => new Paragraph({ spacing: { after: 140 }, children: [] });
const cap = t => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: t, italics: true, size: 20, color: "5D6B63" })] });
function png(path) { const b = fs.readFileSync(path); return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), b }; }
function img(path, width, maxH = 560) {
  const { w, h, b } = png(path);
  if (width * h / w > maxH) width = Math.round(maxH * w / h);      // keep tall screenshots on one page
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 }, children: [new ImageRun({ type: "png", data: b, transformation: { width, height: Math.round(width * h / w) }, altText: { title: path, description: path, name: path } })] });
}
function table(headers, rows, widths) {
  const cell = (t, head, i) => new TableCell({ borders, width: { size: widths[i], type: WidthType.DXA }, margins: { top: 70, bottom: 70, left: 100, right: 100 },
    shading: head ? { type: ShadingType.CLEAR, fill: "14503A" } : undefined,
    children: [new Paragraph({ children: [new TextRun({ text: String(t), bold: head, color: head ? "FFFFFF" : "1D2A24", size: 20 })] })] });
  const row = (cells, head) => new TableRow({ tableHeader: head, children: cells.map((c, i) => cell(c, head, i)) });
  return new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: widths, rows: [row(headers, true), ...rows.map(r => row(r, false))] });
}

const sizeRows = [];
[25, 100, 400, 900, 2500].forEach(sz => ["BFS", "DFS", "Dijkstra", "A*"].forEach((a, i) => {
  const r = get(sz, a); sizeRows.push([i === 0 ? r.locations : "", a, f(r.avg_time_ms, 3), f(r.avg_nodes_explored, 1), f(r.avg_max_frontier, 1), f(r.avg_distance_m, 0), f(r.avg_hops, 1)]);
}));

const kids = [
  new Paragraph({ spacing: { before: 1800, after: 200 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "[Institute Name]", bold: true, size: 28, color: "14503A" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 500 }, children: [new TextRun({ text: "Department of Information Technology", size: 24 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "Design and Analysis of Algorithms – 5th Semester", size: 24 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 700 }, children: [new TextRun({ text: "5-Credit Mini Project Report", size: 24 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 700 }, children: [new TextRun({ text: "Campus Navigation and Path-Finding System", bold: true, size: 44, color: "1F6B4A" })] }),
  P("Group No: [____]", { alignment: AlignmentType.CENTER }),
  P("Students: [Name – Enrollment No.]   |   [Name – Enrollment No.]", { alignment: AlignmentType.CENTER }),
  P("[Name – Enrollment No.]   |   [Name – Enrollment No.]", { alignment: AlignmentType.CENTER }),
  P("Faculty: [Faculty Name]", { alignment: AlignmentType.CENTER }),
  new Paragraph({ children: [new PageBreak()] }),

  H1("1. Problem Definition"),
  P("A visitor or student on a campus wants to get from one building to another. The campus is modelled as a graph in which locations are nodes and walking paths are edges weighted by distance in metres. The task is to find routes between two locations with BFS, DFS, Dijkstra's algorithm and A*, and to compare the algorithms on route quality and on practical performance."),
  table(["Item", "Description"], [
    ["Input", "A campus graph (locations with x, y coordinates in metres; paths with lengths) and a start and destination location"],
    ["Output", "A route (list of locations), its distance in metres, number of hops, places explored, peak queue/stack size and running time for each algorithm"],
    ["Constraints", "Undirected graph; path lengths are positive and never shorter than the straight line between their ends; the destination may be unreachable"],
    ["Objective", "Find the shortest walking route and show how the four algorithms differ in route quality, work done, memory and time"],
  ], [1800, 7226]),
  gap(),
  H1("2. Objectives"),
  B("Represent a campus as a weighted graph using an adjacency list."),
  B("Implement BFS, DFS, Dijkstra's algorithm and A* from scratch."),
  B("Build a web interface that draws every route and the places each algorithm explored."),
  B("Verify correctness with automated tests, including an all-pairs check against Floyd–Warshall."),
  B("Analyse best-, average- and worst-case time and space complexity."),
  B("Compare theory with measurements on campuses of 25 to 2,500 locations."),

  H1("3. Background / Existing Approach"),
  P("BFS and DFS are the basic graph-search methods. BFS finds the route with the fewest hops, but hops are not metres: two short paths can be longer than one long path. DFS finds some route but it can be very long. Dijkstra's algorithm (1959) fixes this by always expanding the nearest unvisited place, which is optimal when distances are non-negative. A* (Hart, Nilsson and Raphael, 1968) adds an estimate of the remaining distance so that the search leans toward the destination. Commercial navigation systems use far more complex methods and live map data; this project stays self-contained and explainable."),

  H1("4. Proposed Approach"),
  P("Flow: Problem definition → Input / data collection (sample campus and generated campuses) → Algorithm selection → Algorithm design / pseudocode → Implementation → Testing with different input sizes → Performance comparison → Results and conclusion."),
  P("The Flask application loads a campus graph, runs all four algorithms on the chosen trip using the same Python functions that the tests and benchmarks use, and returns the routes and measurements as JSON. The browser draws the map in SVG."),

  H1("5. Algorithm Selection and Justification"),
  table(["Algorithm", "Technique", "Why selected"], [
    ["BFS", "Queue, level-by-level", "Simplest search; optimal in number of hops; shows why hops are not distance"],
    ["DFS", "Stack, go deep first", "Simplest way to find any route; shows that finding a route is not finding the best route"],
    ["Dijkstra", "Greedy with a min-heap", "Guaranteed shortest distance; the correctness baseline"],
    ["A*", "Dijkstra guided by a heuristic", "Same guarantee, usually explores fewer places; heuristic is the straight-line distance"],
  ], [1600, 2600, 4826]),
  gap(),

  H1("6. Algorithm / Pseudocode"),
  H2("6.1 BFS"),
  ...code(["queue <- [start]; parent[start] <- none", "while queue not empty:", "    u <- dequeue(queue)", "    if u = goal: stop", "    for each neighbour v of u not yet in parent:", "        parent[v] <- u; enqueue(v)", "route <- follow parent[] from goal back to start"]),
  gap(), H2("6.2 DFS (iterative)"),
  ...code(["stack <- [(start, none)]", "while stack not empty:", "    (u, from) <- pop(stack)", "    if u already visited: continue", "    visited += u; parent[u] <- from", "    if u = goal: stop", "    for each neighbour v of u not visited: push (v, u)"]),
  gap(), H2("6.3 Dijkstra"),
  ...code(["dist[start] <- 0; heap <- [(0, start)]", "while heap not empty:", "    (d, u) <- pop smallest(heap)", "    if u already done: continue", "    mark u done", "    if u = goal: stop", "    for each (v, w) of u:", "        if d + w < dist[v]:", "            dist[v] <- d + w; parent[v] <- u; push (d + w, v)"]),
  gap(), H2("6.4 A*"),
  ...code(["Same as Dijkstra, but the heap key is f(v) = g(v) + h(v)", "    g(v) = distance travelled so far", "    h(v) = straight-line distance from v to the goal", "Because h never over-estimates, the first time the goal is popped its", "route is a shortest route."]),
  gap(),
  P("Why h is safe (admissible and consistent): a walking path is never shorter than the straight line between its ends. The graph class rejects any path shorter than that, so h(u) ≤ w(u,v) + h(v) for every edge. This means A* returns the shortest route and never needs to expand a place twice."),

  H1("7. Complexity Analysis"),
  P("V = number of locations, E = number of paths. The graph is stored as an adjacency list."),
  table(["Algorithm", "Best case", "Average case", "Worst case", "Space"], [
    ["BFS", "O(1) start = goal", "O(V+E)", "O(V+E)", "O(V)"],
    ["DFS", "O(1) start = goal", "O(V+E)", "O(V+E)", "O(V)"],
    ["Dijkstra", "O(1) start = goal", "O((V+E) log V)", "O((V+E) log V)", "O(V)"],
    ["A*", "O(1) start = goal", "below Dijkstra in practice", "O((V+E) log V)", "O(V)"],
  ], [1500, 2000, 2200, 2000, 1326]),
  gap(),
  P("The log V factor comes from the binary heap. BFS and DFS touch each location and path at most once, so they are linear. A* has the same worst case as Dijkstra (a poor heuristic gives no help), but a good heuristic lets it stop after exploring only part of the graph. Extra space is the parent/distance maps plus the queue, stack or heap, all O(V); the graph itself is O(V+E)."),

  H1("8. System Design and Implementation"),
  table(["Part", "Purpose"], [
    ["graph/graph.py", "CampusGraph: adjacency list, straight-line distance (heuristic), input validation, connected-component helper"],
    ["graph/data.py", "Loads data/campus.json (sample campus) and generates synthetic campuses of any size with fixed random seeds"],
    ["algorithms/", "bfs.py, dfs.py, dijkstra.py, astar.py; common.py builds the result (route, distance, hops, explored places, peak queue size, time)"],
    ["app.py, templates/, static/", "Flask web interface: map, route overlays, comparison cards and table, performance page"],
    ["benchmarking/benchmark.py", "Timing, memory (tracemalloc) and charts; writes CSV/JSON into results/"],
    ["tests/", "17 pytest tests"],
    ["demo.py", "Terminal version of the comparison"],
  ], [2600, 6426]),
  P("Language and libraries: Python 3 with the standard library (collections.deque, heapq); Flask for the web app; matplotlib for charts; pytest for tests. No external data or APIs. The sample campus (24 locations, 41 paths) is fictional and for demonstration; real distances can be placed in data/campus.json.", { spacing: { before: 160, after: 120 } }),
  P("To run: python app.py  |  python demo.py BUS SPORT  |  pytest -q  |  python benchmarking/benchmark.py"),

  H1("9. Testing with Different Input Sizes"),
  P("Correctness tests (17, all passing): every one of the 552 ordered pairs on the sample campus is checked, Dijkstra against Floyd–Warshall and A* against Dijkstra; BFS is checked to have the fewest hops and DFS never to beat Dijkstra; there are tests for same-location trips, unreachable places, rejected invalid paths, determinism of generated campuses and heuristic admissibility."),
  P("Performance tests: synthetic campuses of about 25, 100, 400, 900 and 2,500 locations (jittered grid, random path lengths 1.0–1.4 times the straight line, about 15% of paths removed, biggest connected part kept). Seven different campuses (fixed seeds) per size, query from one corner to the opposite corner, fastest of three runs per query. Memory is the peak from tracemalloc on one run per size."),
  P("Table 1: Synthetic campuses, average of 7 campuses per size", { keepNext: true }),
  table(["Locations", "Algorithm", "Time (ms)", "Explored", "Peak queue", "Route (m)", "Hops"], sizeRows, [1200, 1400, 1300, 1300, 1400, 1300, 1126]),
  gap(),
  P("Table 2: Sample campus, all 552 possible trips (average per trip)", { keepNext: true }),
  table(["Algorithm", "Time (ms)", "Places explored", "Route (m)", "Hops"], campus.map(r => [r.algorithm, f(r.avg_time_ms, 4), f(r.avg_nodes_explored, 2), f(r.avg_distance_m, 1), f(r.avg_hops, 2)]), [1800, 1800, 2000, 1900, 1526]),
  gap(),
  P("Table 3: Peak memory (KB) on one run per size", { keepNext: true }),
  table(["Locations", "BFS", "DFS", "Dijkstra", "A*"], [...new Set(mem.map(r => r.locations))].map(l => [l, ...["BFS", "DFS", "Dijkstra", "A*"].map(a => f(mem.find(r => r.locations === l && r.algorithm === a).peak_kb, 1))]), [1800, 1800, 1800, 1800, 1826]),

  H1("10. Results and Performance Comparison"),
  img(R + "performance_time.png", 430), cap("Figure 1: Search time vs campus size (log scale)"),
  img(R + "performance_nodes.png", 430), cap("Figure 2: Locations explored vs campus size"),
  img(R + "performance_distance.png", 430), cap("Figure 3: Length of the route found vs campus size"),
  img(R + "performance_memory.png", 430), cap("Figure 4: Peak memory vs campus size"),
  H2("Observations"),
  B(`Route quality: Dijkstra and A* returned identical (shortest) distances on every run. At 2,500 locations BFS routes averaged ${f(B25.avg_distance_m, 0)} m versus ${f(D25.avg_distance_m, 0)} m for the shortest (${Math.round((B25.avg_distance_m / D25.avg_distance_m - 1) * 100)}% longer), and DFS routes averaged ${f(F25.avg_distance_m, 0)} m (${f(F25.avg_distance_m / D25.avg_distance_m, 1)} times the shortest).`),
  B(`Work done: A* explored ${pct(A25.avg_nodes_explored, D25.avg_nodes_explored)}% fewer places than Dijkstra at 2,500 locations (${f(A25.avg_nodes_explored, 0)} vs ${f(D25.avg_nodes_explored, 0)}) and ${pct(A4.avg_nodes_explored, D4.avg_nodes_explored)}% fewer at 400. On the sample campus, averaged over all 552 trips, A* explored ${f(cA.avg_nodes_explored, 1)} places per trip against ${f(cD.avg_nodes_explored, 0)} for Dijkstra, BFS and DFS. (The three others visit places in an order that does not depend on the destination, so over all 23 possible destinations the goal is reached at positions 2, 3, ..., 24 and the average is always (24+2)/2 = 13.)`),
  B(`Time: fewer explored places did not make A* faster in these Python runs on large campuses (${f(A25.avg_time_ms, 2)} ms for A* vs ${f(D25.avg_time_ms, 2)} ms for Dijkstra at 2,500 locations) because every step also computes the straight-line distance and a larger heap is kept. On the small sample campus A* was faster (${f(cA.avg_time_ms, 4)} vs ${f(cD.avg_time_ms, 4)} ms). A* also holds a larger frontier than Dijkstra.`),
  B(`DFS is by far the fastest and smallest in time and memory (${f(F25.avg_time_ms, 2)} ms at 2,500 locations) because it stops at the first route it finds, but that route is long. BFS is faster than Dijkstra (no heap) but not optimal in distance.`),
  B(`Growth: time for all four algorithms rises roughly in proportion to the number of locations plus paths; the extra log V factor of the heap in Dijkstra and A* is too small to see at these sizes. This is consistent with the theory.`),
  P("Absolute times depend on the machine and Python version; the trends and the counts of explored places are what matter.", { spacing: { before: 120, after: 120 } }),

  H1("11. Screenshots of Working Project"),
  img(S + "01_input_screen.png", 440), cap("Figure 5: Input screen – choose campus map, start and destination"),
  img(S + "02_routes_output.png", 440, 600), cap("Figure 6: Output screen – all four routes on the map, result cards and comparison table"),
  img(S + "03_astar_explored.png", 440), cap("Figure 7: Processing view – places explored by A* (shaded)"),
  img(S + "04_dijkstra_explored.png", 440), cap("Figure 8: Processing view – places explored by Dijkstra (shaded)"),
  img(S + "05_large_campus.png", 440, 600), cap("Figure 9: Large synthetic campus (399 locations)"),
  img(S + "06_performance_results.png", 440, 640), cap("Figure 10: Performance results page"),

  H1("12. Advantages and Limitations"),
  H2("Advantages"),
  B("Simple, readable implementations that are easy to explain."),
  B("Four algorithms compared on identical inputs with identical measurements."),
  B("Verified by exhaustive tests against an independent algorithm."),
  B("Visual explanation of what each algorithm explores."),
  H2("Limitations"),
  B("The sample campus is fictional; costs are distances only (no stairs, crowds or accessibility)."),
  B("Python timings include interpreter overhead, so absolute numbers are not those of a production system."),
  B("Single source and single destination; no live data."),

  H1("13. Future Scope"),
  B("Import a real campus map (for example from survey data) and add landmarks."),
  B("Accessibility-aware or time-dependent costs; multi-stop trips."),
  B("Bidirectional search or precomputed landmarks for faster A*."),

  H1("14. Conclusion"),
  P(`The project models a campus as a weighted graph and implements BFS, DFS, Dijkstra and A*. BFS minimises hops and DFS finds any route, but only Dijkstra and A* guarantee the shortest walking distance. A* matches Dijkstra's routes while exploring about ${pct(A25.avg_nodes_explored, D25.avg_nodes_explored)}–${pct(A4.avg_nodes_explored, D4.avg_nodes_explored)}% fewer places on larger campuses, although in plain Python this saving does not always show up as lower running time. Measurements agree with the theoretical complexities.`),

  H1("15. References"),
  B("E. W. Dijkstra, A note on two problems in connexion with graphs, Numerische Mathematik 1, 1959."),
  B("P. E. Hart, N. J. Nilsson, B. Raphael, A formal basis for the heuristic determination of minimum cost paths, IEEE Trans. SSC 4(2), 1968."),
  B("T. H. Cormen, C. E. Leiserson, R. L. Rivest, C. Stein, Introduction to Algorithms, MIT Press."),
  B("Python 3 (heapq, collections), Flask, pytest and matplotlib documentation. No external datasets; all campus data is generated or hand-made in this project."),
];

const doc = new Document({
  styles: { default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, font: "Cambria", color: "14503A" }, paragraph: { spacing: { before: 320, after: 140 }, outlineLevel: 0, keepNext: true } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, font: "Cambria", color: "1F6B4A" }, paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1, keepNext: true } } ] },
  numbering: { config: [{ reference: "b", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }] },
  sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "DAA Mini Project – Campus Navigation and Path-Finding System – Page ", size: 18, color: "5D6B63" }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "5D6B63" })] })] }) },
    children: kids }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync("Campus_Navigation_Mini_Project_Report.docx", b); console.log("ok"); });
