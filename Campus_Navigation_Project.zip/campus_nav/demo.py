"""Command-line demo (no web server needed).
Usage: python demo.py [START_ID] [GOAL_ID]      e.g.  python demo.py BUS SPORT
Location ids are in data/campus.json (GATE, BUS, LIB, CSD, ...)."""
import sys
from algorithms import ALGORITHMS
from graph.data import load_campus


def main(start="BUS", goal="SPORT"):
    g = load_campus()
    print(f"Sample campus: {len(g.nodes)} locations, {g.edge_count()} paths")
    print(f"Trip: {g.nodes[start].name} -> {g.nodes[goal].name}\n")
    print(f"{'Algorithm':<10}{'Distance':>10}{'Hops':>6}{'Explored':>10}{'Peak queue':>12}{'Time (ms)':>11}  Guarantee")
    results = []
    for name, fn in ALGORITHMS:
        fn(g, start, goal)                       # warm-up
        r = fn(g, start, goal); results.append(r)
        print(f"{name:<10}{r['cost']:>8.0f} m{r['hops']:>6}{r['nodes_explored']:>10}{r['max_frontier']:>12}{r['time_ms']:>11.4f}  {r['guarantee']}")
    print()
    for r in results:
        print(f"{r['algorithm']:<9}: " + " -> ".join(g.nodes[i].name for i in r["path"]))


if __name__ == "__main__":
    main(*sys.argv[1:3])
