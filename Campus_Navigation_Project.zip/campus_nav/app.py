"""Flask web interface for the Campus Navigation and Path-Finding System."""
import csv
from functools import lru_cache
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_from_directory

from algorithms import ALGORITHMS
from graph.data import SCENARIOS, build_scenario, far_pair

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
app = Flask(__name__)


@lru_cache(maxsize=None)
def get_graph(scenario):
    return build_scenario(scenario)


def default_query(scenario, graph):
    return ("GATE", "HOSB") if scenario == "campus" else far_pair(graph)


@app.route("/")
def index():
    return render_template("index.html", scenarios=SCENARIOS)


@app.route("/api/network")
def network():
    scenario = request.args.get("scenario", "campus")
    if scenario not in SCENARIOS:
        return jsonify(error="Unknown scenario"), 400
    g = get_graph(scenario)
    start, goal = default_query(scenario, g)
    return jsonify(g.to_dict() | {"default_start": start, "default_goal": goal})


@app.route("/api/route", methods=["POST"])
def route():
    body = request.get_json(silent=True) or {}
    scenario, start, goal = body.get("scenario", "campus"), body.get("start"), body.get("goal")
    if scenario not in SCENARIOS:
        return jsonify(error="Unknown scenario"), 400
    g = get_graph(scenario)
    if start not in g.nodes or goal not in g.nodes:
        return jsonify(error="Choose a valid start and destination."), 400
    results = []
    for name, fn in ALGORITHMS:
        fn(g, start, goal)                      # warm-up run so timings are fair
        results.append(fn(g, start, goal))
    return jsonify(results=results)


@app.route("/benchmark")
def benchmark_page():
    def table(name):
        f = RESULTS / name
        return list(csv.DictReader(f.open())) if f.exists() else []
    summary, campus = table("benchmark_summary.csv"), table("campus_all_pairs.csv")
    sizes = sorted({int(r["size"]) for r in summary})
    return render_template("benchmark.html", summary=summary, campus=campus, sizes=sizes,
                           algos=[n for n, _ in ALGORITHMS])


@app.route("/results/<path:filename>")
def results_file(filename):
    return send_from_directory(RESULTS, filename)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
