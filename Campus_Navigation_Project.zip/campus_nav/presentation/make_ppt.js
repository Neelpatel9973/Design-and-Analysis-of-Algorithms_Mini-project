const pptxgen = require("pptxgenjs");
const fs = require("fs");
const React = require("react"), ReactDOMServer = require("react-dom/server"), sharp = require("sharp"), fa = require("react-icons/fa");
const R = "../results/", S = "../screenshots/";
const csv = f => { const [h, ...rows] = fs.readFileSync(R + f, "utf8").trim().split("\n").map(l => l.trim().split(",")); return rows.map(r => Object.fromEntries(h.map((k, i) => [k, r[i]]))); };
const summary = csv("benchmark_summary.csv"), campus = csv("campus_all_pairs.csv");
const get = (size, alg) => summary.find(r => +r.size === size && r.algorithm === alg);
const f = (v, d = 2) => (+v).toFixed(d);
const pct = (a, b) => Math.round((1 - a / b) * 100);
const png = p => { const b = fs.readFileSync(p); return b.readUInt32BE(16) / b.readUInt32BE(20); };   // aspect w/h

const DK = "14503A", GR = "1F6B4A", LT = "F4F6F1", INK = "1D2A24", MUTED = "5D6B63", WHITE = "FFFFFF", AC = "EB6834";
const C = { BFS: "2A78D6", DFS: "EB6834", Dijkstra: "1BAF7A", "A*": "E87BA4" };
const HF = "Cambria", BF = "Calibri";
async function icon(Comp, color = "#FFFFFF") {
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Comp, { color, size: "256" }));
  return "image/png;base64," + (await sharp(Buffer.from(svg)).png().toBuffer()).toString("base64");
}
const sh = () => ({ type: "outer", color: "000000", blur: 8, offset: 2, angle: 90, opacity: 0.12 });

(async () => {
  const pres = new pptxgen(); pres.layout = "LAYOUT_WIDE"; pres.title = "Campus Navigation and Path-Finding System";
  const slide = (title, notes) => { const s = pres.addSlide(); s.background = { color: LT };
    s.addText(title, { x: 0.6, y: 0.3, w: 12.1, h: 0.8, fontFace: HF, fontSize: 34, bold: true, color: DK, margin: 0, isTextBox: true }); if (notes) s.addNotes(notes); return s; };
  const card = (s, x, y, w, h, fill = WHITE) => s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: fill }, shadow: sh() });
  const circ = (s, img, x, y, d = 0.7, fill = GR) => { s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: fill } }); s.addImage({ data: img, x: x + d * .25, y: y + d * .25, w: d * .5, h: d * .5 }); };
  const hdr = t => ({ text: t, options: { bold: true, color: WHITE, fill: { color: DK }, fontFace: BF, fontSize: 14 } });
  const cell = (t, o = {}) => ({ text: String(t), options: Object.assign({ fontFace: BF, fontSize: 14, color: INK, valign: "middle" }, o) });
  const pic = (s, path, x, y, w, h) => { const a = png(path); let ww = w, hh = w / a; if (hh > h) { hh = h; ww = h * a; } s.addImage({ path, x: x + (w - ww) / 2, y: y + (h - hh) / 2, w: ww, h: hh }); };
  const D25 = get(2500, "Dijkstra"), A25 = get(2500, "A*"), B25 = get(2500, "BFS"), F25 = get(2500, "DFS"), D4 = get(400, "Dijkstra"), A4 = get(400, "A*");

  // 1 Title
  let s = pres.addSlide(); s.background = { color: DK };
  s.addText("DESIGN AND ANALYSIS OF ALGORITHMS  |  5th Semester  |  Mini Project", { x: .8, y: .7, w: 11.5, h: .4, fontFace: BF, fontSize: 14, color: "A9CDB9", margin: 0, isTextBox: true });
  s.addText("Campus Navigation and Path-Finding System", { x: .8, y: 1.5, w: 7.6, h: 2.2, fontFace: HF, fontSize: 44, bold: true, color: WHITE, margin: 0, valign: "top", isTextBox: true });
  s.addText("Routes between campus locations with BFS, DFS, Dijkstra and A*", { x: .8, y: 3.9, w: 7.2, h: .8, fontFace: BF, fontSize: 18, italic: true, color: "A9CDB9", margin: 0, isTextBox: true });
  s.addText([{ text: "Group No: [____]", options: { breakLine: true } }, { text: "Members: [Name – Enrollment No.]", options: { breakLine: true } }, { text: "[Name – Enrollment No.]", options: { breakLine: true } }, { text: "[Name – Enrollment No.]", options: { breakLine: true } }, { text: "Faculty: [Faculty Name]" }],
    { x: .8, y: 5.1, w: 7.5, h: 1.8, fontFace: BF, fontSize: 15, color: WHITE, margin: 0, paraSpaceAfter: 4, isTextBox: true });
  const nodes = [[9.4, 3.2], [10.4, 2.1], [11.7, 2.6], [11.9, 4.1], [10.6, 4.6], [9.7, 5.6]], ed = [[0, 1, 1], [1, 2, 1], [2, 3, 1], [0, 4, 0], [4, 3, 0], [4, 5, 0]];
  ed.forEach(([a, b, c]) => { const [x1, y1] = nodes[a], [x2, y2] = nodes[b]; s.addShape(pres.shapes.LINE, { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1), h: Math.abs(y2 - y1), flipV: (y2 < y1) !== (x2 < x1), line: { color: c ? "1BAF7A" : "5F8A74", width: c ? 4 : 1.5 } }); });
  nodes.forEach(([x, y], i) => s.addShape(pres.shapes.OVAL, { x: x - .28, y: y - .28, w: .56, h: .56, fill: { color: i === 5 ? "D9342B" : i === 0 ? "1D2A24" : "2E7D5B" }, line: { color: WHITE, width: 1.5 } }));
  s.addNotes("Introduce the topic: finding routes on a campus map using four graph-search algorithms.");

  // 2 Problem
  s = slide("Problem Statement", "Inputs, outputs, constraints and objective.");
  s.addText("Represent campus locations as a weighted graph and find routes between two locations with BFS, DFS, Dijkstra and A*, then compare the algorithms on route quality and performance.", { x: .6, y: 1.3, w: 12.1, h: 1, fontFace: BF, fontSize: 18, color: INK, margin: 0, valign: "top", isTextBox: true });
  [["INPUT", "Campus graph (locations with x, y in metres; walking paths with lengths), start and destination"], ["OUTPUT", "Route, distance (m), hops, places explored, peak queue size and time for each algorithm"], ["CONSTRAINTS", "Undirected graph; path lengths positive and never shorter than the straight line; destination may be unreachable"], ["OBJECTIVE", "Find the shortest walking route and show how the four algorithms differ in quality and cost"]].forEach((p, i) => {
    const x = .6 + (i % 2) * 6.15, y = 2.55 + Math.floor(i / 2) * 2.25; card(s, x, y, 5.95, 2);
    s.addText(p[0], { x: x + .3, y: y + .2, w: 5.3, h: .4, fontFace: BF, fontSize: 14, bold: true, color: AC, margin: 0, isTextBox: true });
    s.addText(p[1], { x: x + .3, y: y + .7, w: 5.3, h: 1.1, fontFace: BF, fontSize: 16, color: INK, margin: 0, valign: "top", isTextBox: true }); });

  // 3 Motivation
  s = slide("Motivation and Real-World Application", "Why path-finding matters.");
  const ic = [await icon(fa.FaMapMarkedAlt), await icon(fa.FaUniversity), await icon(fa.FaWheelchair), await icon(fa.FaCogs)];
  [["Where it is used", "Maps and navigation apps, delivery routing, game AI, robotics, indoor wayfinding in campuses, hospitals and malls."], ["Why it matters", "New students and visitors lose time on large campuses; a good route saves walking distance."], ["Who benefits", "Students, visitors, event organisers and campus administrators planning signage and shuttles."], ["Why it suits DAA", "Same problem, four algorithms with different guarantees and costs: a clean case for complexity and experiments."]].forEach((m, i) => {
    const y = 1.45 + i * 1.4; circ(s, ic[i], .7, y + .15, .8); s.addText(m[0], { x: 1.8, y, w: 10.8, h: .45, fontFace: HF, fontSize: 20, bold: true, color: DK, margin: 0, isTextBox: true });
    s.addText(m[1], { x: 1.8, y: y + .5, w: 10.8, h: .7, fontFace: BF, fontSize: 16, color: INK, margin: 0, valign: "top", isTextBox: true }); });

  // 4 Objectives
  s = slide("Objectives", "Measurable objectives tied to the DAA flow.");
  ["Model the campus as a weighted graph using an adjacency list", "Implement BFS, DFS, Dijkstra and A* from scratch", "Verify correctness with 17 automated tests, including all-pairs checks", "Show routes and explored places in a web interface", "Analyse best, average and worst-case time and space complexity", "Compare theory with measurements for 25 to 2,500 locations"].forEach((o, i) => {
    const x = .6 + (i % 2) * 6.15, y = 1.5 + Math.floor(i / 2) * 1.8; card(s, x, y, 5.95, 1.55);
    s.addShape(pres.shapes.OVAL, { x: x + .3, y: y + .45, w: .65, h: .65, fill: { color: i % 2 ? AC : GR } });
    s.addText(String(i + 1), { x: x + .3, y: y + .45, w: .65, h: .65, fontFace: HF, fontSize: 20, bold: true, color: WHITE, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(o, { x: x + 1.2, y: y + .2, w: 4.5, h: 1.15, fontFace: BF, fontSize: 16, color: INK, margin: 0, valign: "middle", isTextBox: true }); });

  // 5 Existing approach
  s = slide("Existing Approach and Background", "Basic searches and their limits.");
  card(s, .6, 1.5, 5.95, 4.9); s.addText("Basic approach: BFS and DFS", { x: .9, y: 1.7, w: 5.4, h: .5, fontFace: HF, fontSize: 20, bold: true, color: DK, margin: 0, isTextBox: true });
  s.addText([{ text: "BFS: fewest hops, but ignores distance in metres", options: { bullet: true, breakLine: true } }, { text: "DFS: finds some route, often long and winding", options: { bullet: true, breakLine: true } }, { text: "Neither guarantees the shortest walking distance", options: { bullet: true, breakLine: true } }, { text: "Both explore blindly, with no sense of direction", options: { bullet: true } }], { x: .9, y: 2.4, w: 5.4, h: 3.7, fontFace: BF, fontSize: 18, color: INK, margin: 0, valign: "top", paraSpaceAfter: 14, isTextBox: true });
  card(s, 6.8, 1.5, 5.95, 4.9, DK); s.addText("Need for the proposed approach", { x: 7.1, y: 1.7, w: 5.4, h: .5, fontFace: HF, fontSize: 20, bold: true, color: WHITE, margin: 0, isTextBox: true });
  s.addText([{ text: "Dijkstra: always expands the nearest place, guaranteeing the shortest route", options: { bullet: true, breakLine: true } }, { text: "A*: adds a straight-line estimate to head toward the goal", options: { bullet: true, breakLine: true } }, { text: "Compare all four to see the trade-off between route quality and work done", options: { bullet: true } }], { x: 7.1, y: 2.4, w: 5.4, h: 3.7, fontFace: BF, fontSize: 18, color: WHITE, margin: 0, valign: "top", paraSpaceAfter: 14, isTextBox: true });

  // 6 Proposed approach
  s = slide("Proposed Approach", "Flow from problem to results.");
  const st = [["Problem", "Campus routing"], ["Input", "Sample and generated campuses"], ["Select", "BFS, DFS, Dijkstra, A*"], ["Design", "Pseudocode and complexity"], ["Implement", "Python and Flask"], ["Test", "17 tests, 25–2,500 places"], ["Compare", "Quality, work, time, memory"], ["Results", "Tables, charts, conclusion"]];
  st.forEach((t, i) => { const x = .6 + (i % 4) * 3.1, y = 1.6 + Math.floor(i / 4) * 2.45;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.7, h: 1.9, rectRadius: .12, fill: { color: i === 7 ? GR : WHITE }, shadow: sh() });
    s.addText(String(i + 1), { x, y: y + .15, w: 2.7, h: .5, fontFace: HF, fontSize: 24, bold: true, color: i === 7 ? WHITE : AC, align: "center", margin: 0, isTextBox: true });
    s.addText(t[0], { x: x + .1, y: y + .7, w: 2.5, h: .45, fontFace: BF, fontSize: 18, bold: true, color: i === 7 ? WHITE : DK, align: "center", margin: 0, isTextBox: true });
    s.addText(t[1], { x: x + .15, y: y + 1.15, w: 2.4, h: .65, fontFace: BF, fontSize: 14, color: i === 7 ? WHITE : MUTED, align: "center", valign: "top", margin: 0, isTextBox: true });
    if (i % 4 < 3) s.addText("›", { x: x + 2.68, y: y + .7, w: .44, h: .6, fontFace: BF, fontSize: 30, bold: true, color: DK, align: "center", valign: "middle", margin: 0, isTextBox: true }); });

  // 7 Algorithms used
  s = slide("Algorithms Used", "Why each one was chosen.");
  s.addTable([[hdr("Algorithm"), hdr("Basic idea"), hdr("Why selected"), hdr("Data structure")],
    [cell("BFS", { bold: true }), cell("Explore level by level"), cell("Fewest hops; simplest search"), cell("Queue (deque), parent map")],
    [cell("DFS", { bold: true }), cell("Go deep, then backtrack"), cell("Finds any route; shows no optimality"), cell("Stack (list), visited set")],
    [cell("Dijkstra", { bold: true }), cell("Expand nearest place first"), cell("Guaranteed shortest distance"), cell("Min-heap (heapq), distance map")],
    [cell("A*", { bold: true }), cell("Dijkstra + straight-line estimate"), cell("Same guarantee, fewer places explored"), cell("Min-heap on g + h")]],
    { x: .6, y: 1.5, w: 12.1, colW: [2.2, 3.5, 3.6, 2.8], rowH: [.55, .95, .95, .95, .95], border: { type: "solid", color: "D5DBE3", pt: 1 }, fill: { color: WHITE } });

  // 8 Pseudocode
  s = slide("Algorithm / Pseudocode", "Walk through Dijkstra, then show how A* differs.");
  const box = (x, w, ttl, code, fs) => { s.addShape(pres.shapes.RECTANGLE, { x, y: 1.4, w, h: 4.6, fill: { color: "1B2420" }, shadow: sh() });
    s.addText(ttl, { x: x + .25, y: 1.5, w: w - .5, h: .4, fontFace: BF, fontSize: 14, bold: true, color: "8EE3B8", margin: 0, isTextBox: true });
    s.addText(code, { x: x + .25, y: 1.95, w: w - .5, h: 3.95, fontFace: "Courier New", fontSize: fs, color: "E0EAE4", margin: 0, valign: "top", isTextBox: true }); };
  box(.6, 6.6, "Dijkstra", `dist[start] <- 0; heap <- [(0, start)]
while heap not empty:
    (d, u) <- pop smallest
    if u done: continue
    mark u done
    if u = goal: stop
    for (v, w) in neighbours(u):
        if d + w < dist[v]:
            dist[v] <- d + w
            parent[v] <- u
            push (d + w, v)`, 14);
  box(7.45, 5.3, "BFS / DFS / A*", `BFS : queue (FIFO), first seen = parent
DFS : stack (LIFO), go deepest first
A*  : same as Dijkstra, heap key is
      f(v) = g(v) + h(v)
      h = straight-line distance
      to the destination
Route: follow parent[] from goal
       back to start`, 14);
  s.addText("BFS, DFS: O(V+E)    |    Dijkstra, A*: O((V+E) log V)    |    Space: O(V)", { x: .6, y: 6.3, w: 12.1, h: .5, fontFace: BF, fontSize: 18, bold: true, color: AC, margin: 0, isTextBox: true });

  // 9 Architecture
  s = slide("System Design / Architecture", "User, processing, algorithm and output.");
  [["User", "Browser: pick map, start and destination"], ["Flask API", "app.py\n/api/network, /api/route"], ["Algorithms", "BFS, DFS, Dijkstra, A*\nCampusGraph (adjacency list)"], ["Output", "Routes on SVG map\nCards, table, benchmark page"]].forEach((m, i) => {
    const x = .6 + i * 3.1; s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 2.1, w: 2.8, h: 3.1, rectRadius: .12, fill: { color: i === 2 ? DK : WHITE }, shadow: sh() });
    s.addText(m[0], { x: x + .15, y: 2.3, w: 2.5, h: .5, fontFace: HF, fontSize: 20, bold: true, color: i === 2 ? WHITE : DK, align: "center", margin: 0, isTextBox: true });
    s.addText(m[1], { x: x + .2, y: 3.0, w: 2.4, h: 2.0, fontFace: BF, fontSize: 15, color: i === 2 ? "DCEDE3" : INK, align: "center", valign: "top", margin: 0, isTextBox: true });
    if (i < 3) s.addText("›", { x: x + 2.78, y: 3.3, w: .34, h: .6, fontFace: BF, fontSize: 30, bold: true, color: AC, align: "center", valign: "middle", margin: 0, isTextBox: true }); });
  s.addText("Data: data/campus.json (24 places, 41 paths) and generated campuses of 25–400 places for the app, up to 2,500 for benchmarks.", { x: .6, y: 5.7, w: 12.1, h: .6, fontFace: BF, fontSize: 16, italic: true, color: MUTED, margin: 0, isTextBox: true });

  // 10 Implementation
  s = slide("Implementation", "Simple code, standard library only.");
  [["Language and tools", "Python 3. Standard library (deque, heapq, time, tracemalloc); Flask web app; pytest; matplotlib for charts."], ["Important modules", "graph/graph.py, graph/data.py, algorithms/ (one file per algorithm), app.py, benchmarking/benchmark.py, tests/."], ["Data structures", "Adjacency list (dict of lists), deque for BFS, list as stack for DFS, binary min-heap for Dijkstra and A*, dicts and sets for parent and visited."], ["Safety check", "add_path rejects a path shorter than the straight line, so the A* estimate never over-estimates and A* stays optimal."]].forEach((m, i) => {
    const x = .6 + (i % 2) * 6.15, y = 1.5 + Math.floor(i / 2) * 2.5; card(s, x, y, 5.95, 2.25);
    s.addText(m[0], { x: x + .3, y: y + .2, w: 5.3, h: .45, fontFace: HF, fontSize: 19, bold: true, color: AC, margin: 0, isTextBox: true });
    s.addText(m[1], { x: x + .3, y: y + .75, w: 5.3, h: 1.4, fontFace: BF, fontSize: 16, color: INK, margin: 0, valign: "top", isTextBox: true }); });

  // 11 Screenshots
  s = slide("Project Screenshots", "Input, processing, output, performance.");
  const shots = [["../screenshots/01_input_screen.png", "Input screen"], ["../screenshots/03_astar_explored.png", "Processing: places explored by A*"], ["crop_output.png", "Output: all four routes and comparison"], ["crop_perf.png", "Performance results page"]];
  shots.forEach((t, i) => { const x = .6 + (i % 2) * 6.15, y = 1.3 + Math.floor(i / 2) * 2.9; s.addShape(pres.shapes.RECTANGLE, { x, y, w: 5.95, h: 2.6, fill: { color: WHITE }, shadow: sh() });
    pic(s, t[0], x + .07, y + .07, 5.81, 2.46); s.addText(t[1], { x, y: y + 2.62, w: 5.95, h: .3, fontFace: BF, fontSize: 12, italic: true, color: MUTED, align: "center", margin: 0, isTextBox: true }); });

  // 12 Results
  s = slide("Results: Measured Comparison", "Averages over 7 random campuses per size; far-corner query; fastest of 3 runs.");
  const rows = [[hdr("Locations"), hdr("Algorithm"), hdr("Time (ms)"), hdr("Explored"), hdr("Route (m)")]];
  [25, 400, 2500].forEach(sz => ["BFS", "DFS", "Dijkstra", "A*"].forEach((a, i) => { const r = get(sz, a);
    rows.push([cell(i === 0 ? sz.toLocaleString("en-US") : "", { bold: true, fontSize: 13 }), cell(a, { fontSize: 13 }), cell(f(r.avg_time_ms, 3), { fontSize: 13 }), cell(f(r.avg_nodes_explored, 0), { fontSize: 13 }), cell(f(r.avg_distance_m, 0), { fontSize: 13 })]); }));
  s.addTable(rows, { x: .6, y: 1.35, w: 6.9, colW: [1.3, 1.5, 1.4, 1.3, 1.4], rowH: .39, border: { type: "solid", color: "D5DBE3", pt: 1 }, fill: { color: WHITE } });
  s.addText("Sizes are requested locations (generated campuses keep the biggest connected part, so actual counts are 1\u20132 lower). Also tested: 100 and 900, and all 552 trips on the sample campus (see report).", { x: .6, y: 6.5, w: 6.9, h: .5, fontFace: BF, fontSize: 12, italic: true, color: MUTED, margin: 0, isTextBox: true });
  card(s, 7.75, 1.35, 5.0, 2.6); pic(s, R + "performance_nodes.png", 7.8, 1.4, 4.9, 2.5);
  card(s, 7.75, 4.15, 5.0, 2.6); pic(s, R + "performance_distance.png", 7.8, 4.2, 4.9, 2.5);

  // 13 Complexity
  s = slide("Complexity Analysis", "V locations, E paths.");
  s.addTable([[hdr("Algorithm"), hdr("Best"), hdr("Average"), hdr("Worst"), hdr("Space")],
    [cell("BFS", { bold: true }), cell("O(1)"), cell("O(V+E)"), cell("O(V+E)"), cell("O(V)")], [cell("DFS", { bold: true }), cell("O(1)"), cell("O(V+E)"), cell("O(V+E)"), cell("O(V)")],
    [cell("Dijkstra", { bold: true }), cell("O(1)"), cell("O((V+E) log V)"), cell("O((V+E) log V)"), cell("O(V)")], [cell("A*", { bold: true }), cell("O(1)"), cell("below Dijkstra in practice"), cell("O((V+E) log V)"), cell("O(V)")]],
    { x: .6, y: 1.35, w: 12.1, colW: [2.2, 1.6, 3.4, 3.2, 1.7], rowH: .5, border: { type: "solid", color: "D5DBE3", pt: 1 }, fill: { color: WHITE } });
  card(s, .6, 4.1, 12.1, 2.7);
  s.addText([{ text: "Theory vs practice  ", options: { bold: true, color: AC, breakLine: true } },
    { text: `Time grows roughly in step with V+E for all four. A* explored ${pct(A25.avg_nodes_explored, D25.avg_nodes_explored)}% fewer places than Dijkstra at 2,500 locations and ${pct(A4.avg_nodes_explored, D4.avg_nodes_explored)}% fewer at 400, with identical routes.`, options: { breakLine: true } },
    { text: `In Python, though, A* was not faster at large sizes (${f(A25.avg_time_ms, 2)} vs ${f(D25.avg_time_ms, 2)} ms): the heuristic and a larger heap cost extra. DFS was fastest (${f(F25.avg_time_ms, 2)} ms) but its routes were ${f(F25.avg_distance_m / D25.avg_distance_m, 1)}x longer; BFS routes were ${Math.round((B25.avg_distance_m / D25.avg_distance_m - 1) * 100)}% longer.`, options: {} }],
    { x: .9, y: 4.2, w: 11.5, h: 2.5, fontFace: BF, fontSize: 16, color: INK, margin: 0, valign: "top", paraSpaceAfter: 8, isTextBox: true });

  // 14 Adv/Lim/Future
  s = slide("Advantages, Limitations and Future Scope", "Be honest about limitations.");
  const i1 = await icon(fa.FaThumbsUp), i2 = await icon(fa.FaExclamationTriangle), i3 = await icon(fa.FaRocket);
  [["Advantages", i1, GR, ["Simple, readable code", "Four algorithms, same inputs and metrics", "Verified against Floyd–Warshall", "Visual view of explored places"]], ["Limitations", i2, AC, ["Fictional sample campus", "Distance is the only cost", "Python timings, not production speed", "One start and one destination"]], ["Future scope", i3, DK, ["Real campus map data", "Accessibility and crowd-aware costs", "Bidirectional search, landmarks", "Multi-stop trips"]]].forEach((c, i) => {
    const x = .6 + i * 4.1; card(s, x, 1.5, 3.9, 4.9); circ(s, c[1], x + .3, 1.75, .65, c[2]);
    s.addText(c[0], { x: x + 1.1, y: 1.75, w: 2.6, h: .65, fontFace: HF, fontSize: 20, bold: true, color: DK, valign: "middle", margin: 0, isTextBox: true });
    s.addText(c[3].map((t, k) => ({ text: t, options: { bullet: true, breakLine: k < 3 } })), { x: x + .3, y: 2.65, w: 3.4, h: 3.5, fontFace: BF, fontSize: 16, color: INK, margin: 0, valign: "top", paraSpaceAfter: 10, isTextBox: true }); });

  // 15 Conclusion
  s = pres.addSlide(); s.background = { color: DK };
  s.addText("Conclusion and References", { x: .6, y: .35, w: 12.1, h: .8, fontFace: HF, fontSize: 34, bold: true, color: WHITE, margin: 0, isTextBox: true });
  s.addText([{ text: "Campus modelled as a weighted graph; four algorithms implemented and tested.", options: { bullet: true, breakLine: true } }, { text: "Only Dijkstra and A* guarantee the shortest route; BFS minimises hops, DFS finds any route.", options: { bullet: true, breakLine: true } }, { text: "A* explored 20–27% fewer places on larger campuses with identical routes.", options: { bullet: true, breakLine: true } }, { text: "Measurements agree with O(V+E) and O((V+E) log V) theory.", options: { bullet: true } }],
    { x: .6, y: 1.5, w: 6.0, h: 4.6, fontFace: BF, fontSize: 19, color: WHITE, margin: 0, valign: "top", paraSpaceAfter: 16, isTextBox: true });
  s.addShape(pres.shapes.RECTANGLE, { x: 7.0, y: 1.5, w: 5.75, h: 5.0, fill: { color: "1D6045" } });
  s.addText("References", { x: 7.3, y: 1.65, w: 5.2, h: .4, fontFace: HF, fontSize: 18, bold: true, color: "F6C9A8", margin: 0, isTextBox: true });
  s.addText([{ text: "Dijkstra (1959). A note on two problems in connexion with graphs. Numerische Mathematik 1.", options: { bullet: true, breakLine: true } }, { text: "Hart, Nilsson, Raphael (1968). A formal basis for the heuristic determination of minimum cost paths. IEEE SSC 4(2).", options: { bullet: true, breakLine: true } }, { text: "Cormen, Leiserson, Rivest, Stein. Introduction to Algorithms. MIT Press.", options: { bullet: true, breakLine: true } }, { text: "Python, Flask, pytest, matplotlib documentation. No external datasets.", options: { bullet: true } }],
    { x: 7.3, y: 2.2, w: 5.2, h: 4.1, fontFace: BF, fontSize: 15, color: WHITE, margin: 0, valign: "top", paraSpaceAfter: 10, isTextBox: true });

  await pres.writeFile({ fileName: "Campus_Navigation_Mini_Project_Presentation.pptx" }); console.log("saved");
})();
