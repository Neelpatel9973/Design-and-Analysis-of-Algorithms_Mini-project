import time
from algorithms.common import build_result


def dfs(graph, start, goal):
    """Depth-First Search (iterative, uses a stack): goes as deep as possible first.
    Finds A route, but it is usually long and winding - no optimality guarantee."""
    t0 = time.perf_counter()
    stack = [(start, None)]         # (node, node we came from)
    parent, visited = {}, set()
    explored, max_frontier = [], 1
    while stack:
        current, came_from = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        parent[current] = came_from
        explored.append(current)
        if current == goal:
            break
        for neighbour, _ in graph.adjacency[current]:
            if neighbour not in visited:
                stack.append((neighbour, current))
        max_frontier = max(max_frontier, len(stack))
    return build_result("DFS", "Any route (not optimal)", graph, parent, start, goal, explored, max_frontier, t0)
