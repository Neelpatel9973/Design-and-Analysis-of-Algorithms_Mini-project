import heapq
import time
from algorithms.common import build_result


def dijkstra(graph, start, goal):
    """Dijkstra: always expand the unvisited node with the smallest distance so far
    (min-heap). Guaranteed shortest distance because all path lengths are >= 0."""
    t0 = time.perf_counter()
    dist = {start: 0.0}
    parent = {start: None}
    heap = [(0.0, start)]           # (distance so far, node)
    done = set()
    explored, max_frontier = [], 1
    while heap:
        d, current = heapq.heappop(heap)
        if current in done:         # stale heap entry
            continue
        done.add(current)
        explored.append(current)
        if current == goal:
            break
        for neighbour, weight in graph.adjacency[current]:
            new_d = d + weight
            if new_d < dist.get(neighbour, float("inf")):
                dist[neighbour] = new_d
                parent[neighbour] = current
                heapq.heappush(heap, (new_d, neighbour))
        max_frontier = max(max_frontier, len(heap))
    return build_result("Dijkstra", "Shortest distance", graph, parent, start, goal, explored, max_frontier, t0)
