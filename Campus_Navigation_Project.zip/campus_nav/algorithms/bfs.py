import time
from collections import deque
from algorithms.common import build_result


def bfs(graph, start, goal):
    """Breadth-First Search: explores level by level with a queue.
    Finds the route with the FEWEST paths (hops); ignores distances."""
    t0 = time.perf_counter()
    queue = deque([start])
    parent = {start: None}          # doubles as the 'seen' set
    explored, max_frontier = [], 1
    while queue:
        current = queue.popleft()
        explored.append(current)
        if current == goal:
            break
        for neighbour, _ in graph.adjacency[current]:
            if neighbour not in parent:
                parent[neighbour] = current
                queue.append(neighbour)
        max_frontier = max(max_frontier, len(queue))
    return build_result("BFS", "Fewest hops", graph, parent, start, goal, explored, max_frontier, t0)
