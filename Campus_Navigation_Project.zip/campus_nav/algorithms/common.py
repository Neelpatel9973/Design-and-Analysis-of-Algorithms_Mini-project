import time


def build_result(name, guarantee, graph, parent, start, goal, explored, max_frontier, t0):
    """Package a search outcome. `parent` maps each reached node to the node we came from."""
    elapsed_ms = (time.perf_counter() - t0) * 1000   # stop the clock before building the path
    path = []
    if goal in parent:
        node = goal
        while node is not None:
            path.append(node)
            node = parent[node]
        path.reverse()
    return {
        "algorithm": name,
        "guarantee": guarantee,
        "found": bool(path),
        "path": path,
        "cost": graph.path_distance(path) if path else None,   # metres
        "hops": len(path) - 1 if path else None,               # number of paths walked
        "nodes_explored": len(explored),
        "explored": explored,                                  # order in which nodes were visited
        "max_frontier": max_frontier,                          # largest queue/stack size (space)
        "time_ms": elapsed_ms,
    }
