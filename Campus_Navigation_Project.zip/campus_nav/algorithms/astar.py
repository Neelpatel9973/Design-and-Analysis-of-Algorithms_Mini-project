import heapq
import time
from algorithms.common import build_result


def astar(graph, start, goal):
    """A*: like Dijkstra, but orders the heap by f = g + h where g is the distance so
    far and h is the straight-line distance to the goal. Because h never over-estimates
    (see CampusGraph.add_path), the route is still the shortest, but fewer nodes are explored."""
    t0 = time.perf_counter()
    g_cost = {start: 0.0}
    parent = {start: None}
    heap = [(graph.heuristic(start, goal), start)]    # (f = g + h, node)
    done = set()
    explored, max_frontier = [], 1
    while heap:
        _, current = heapq.heappop(heap)
        if current in done:
            continue
        done.add(current)
        explored.append(current)
        if current == goal:
            break
        for neighbour, weight in graph.adjacency[current]:
            new_g = g_cost[current] + weight
            if new_g < g_cost.get(neighbour, float("inf")):
                g_cost[neighbour] = new_g
                parent[neighbour] = current
                heapq.heappush(heap, (new_g + graph.heuristic(neighbour, goal), neighbour))
        max_frontier = max(max_frontier, len(heap))
    return build_result("A*", "Shortest distance", graph, parent, start, goal, explored, max_frontier, t0)
