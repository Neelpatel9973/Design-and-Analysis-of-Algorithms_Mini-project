from algorithms.bfs import bfs
from algorithms.dfs import dfs
from algorithms.dijkstra import dijkstra
from algorithms.astar import astar

ALGORITHMS = [("BFS", bfs), ("DFS", dfs), ("Dijkstra", dijkstra), ("A*", astar)]
