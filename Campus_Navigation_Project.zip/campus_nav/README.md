# Campus Navigation and Path-Finding System

DAA 5th-semester mini project (Topic 9). Locations on a campus form a weighted graph; the system finds routes between two places with **BFS, DFS, Dijkstra's algorithm and A\*** and compares them on route quality, places explored, queue size, time and memory.

## Features
- Flask web app: pick a start and a destination, run all four algorithms, see every route drawn on the map, the places each one explored, and a side-by-side table.
- Hand-written algorithms (simple, commented code, standard library only: `deque`, `heapq`).
- Hand-made sample campus (24 places, 41 paths) plus three synthetic campuses (25, 100, 400 places) for larger tests.
- 17 pytest tests, including an all-pairs check against Floyd-Warshall.
- Benchmarks (25 to 2500 locations) with CSV/JSON and four charts in `results/`.

## Install and run
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py                  # open http://127.0.0.1:5000
python demo.py BUS SPORT       # same comparison in the terminal
pytest -q                      # tests
python benchmarking/benchmark.py   # regenerate results/
```

## Structure
| Path | Purpose |
|---|---|
| `app.py` | Flask routes (`/`, `/api/network`, `/api/route`, `/benchmark`) |
| `graph/graph.py` | `CampusGraph`: adjacency list, straight-line heuristic, validation |
| `graph/data.py` | Loads the sample campus, generates synthetic campuses |
| `algorithms/` | `bfs.py`, `dfs.py`, `dijkstra.py`, `astar.py`, shared `common.py` |
| `benchmarking/benchmark.py` | Timing, memory, charts |
| `tests/` | pytest suite |
| `data/campus.json` | Sample campus (edit to use your own); `campus_source.py` regenerates it |
| `templates/`, `static/` | Web interface |
| `results/`, `screenshots/` | Measured output and screenshots of the running app |
| `report/` | Report (`.docx`) and its generator `make_report.js` |
| `presentation/` | 15-slide deck (`.pptx`) and its generator `make_ppt.js` |
| `VIVA_QA.md` | Viva preparation |

## Complexity (V locations, E paths)
| Algorithm | Time | Space | Finds |
|---|---|---|---|
| BFS | O(V+E) | O(V) | fewest hops |
| DFS | O(V+E) | O(V) | any route |
| Dijkstra | O((V+E) log V) | O(V) | shortest distance |
| A* | O((V+E) log V) worst case | O(V) | shortest distance, usually fewer places explored |

## Notes and integrity
- The campus is an illustrative sample, not a real survey. Replace `data/campus.json` for your own campus.
- Libraries: Flask (web), pytest (tests), matplotlib (charts). No external APIs or datasets.
- Timings are machine dependent; rerun the benchmark on the machine you demo with and retake screenshots from your own run.
- Every group member must be able to explain all four algorithms and the code.
