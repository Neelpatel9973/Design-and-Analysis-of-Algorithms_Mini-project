"""Builds the graphs used by the app, tests and benchmarks (all offline, no APIs)."""
import json
import math
import random
from pathlib import Path

from graph.graph import CampusGraph

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "campus.json"

# name -> (label, approximate number of locations for the synthetic ones)
SCENARIOS = {
    "campus": "Sample campus (24 locations)",
    "small": "Small synthetic (25 locations)",
    "medium": "Medium synthetic (100 locations)",
    "large": "Large synthetic (400 locations)",
}
SYNTHETIC_SIZE = {"small": 25, "medium": 100, "large": 400}


def load_campus():
    """The hand-made sample campus stored in data/campus.json."""
    raw = json.loads(DATA_FILE.read_text())
    g = CampusGraph()
    for n in raw["nodes"]:
        g.add_location(n["id"], n["name"], n["x"], n["y"])
    for e in raw["edges"]:
        g.add_path(e["from"], e["to"], e["weight"])
    return g


def generate_campus(size, seed=1):
    """Synthetic campus: a jittered grid of ~`size` locations. Every path is 1.0-1.4x
    its straight-line length; ~15% of paths are removed, and only the biggest
    connected part is kept. Deterministic for a given (size, seed)."""
    rng = random.Random(seed)
    side = max(2, math.ceil(math.sqrt(size)))
    g = CampusGraph()
    for r in range(side):
        for c in range(side):
            g.add_location(f"N{r * side + c}", f"Junction {r * side + c}",
                           c * 30 + rng.uniform(-8, 8), r * 30 + rng.uniform(-8, 8))
    for r in range(side):
        for c in range(side):
            here = f"N{r * side + c}"
            for dr, dc in ((0, 1), (1, 0), (1, 1)):          # right, down, diagonal
                rr, cc = r + dr, c + dc
                if rr >= side or cc >= side:
                    continue
                if dr == 1 and dc == 1 and rng.random() < 0.7:  # few diagonals
                    continue
                if rng.random() < 0.15:                         # missing path
                    continue
                there = f"N{rr * side + cc}"
                g.add_path(here, there, math.ceil(g.straight_line(here, there) * rng.uniform(1.0, 1.4)))
    keep = set(g.largest_component())
    small = CampusGraph()
    for nid in g.nodes:
        if nid in keep:
            n = g.nodes[nid]
            small.add_location(n.id, n.name, n.x, n.y)
    for a, nbrs in g.adjacency.items():
        for b, w in nbrs:
            if a < b and a in keep:
                small.add_path(a, b, w)
    return small


def build_scenario(name, seed=1):
    if name == "campus":
        return load_campus()
    return generate_campus(SYNTHETIC_SIZE[name], seed)


def far_pair(graph):
    """A long query: the two locations furthest apart along the diagonal."""
    key = lambda i: graph.nodes[i].x + graph.nodes[i].y
    ids = list(graph.nodes)
    return min(ids, key=key), max(ids, key=key)
