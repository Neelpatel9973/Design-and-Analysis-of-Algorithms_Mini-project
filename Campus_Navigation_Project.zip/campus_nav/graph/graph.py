"""Campus graph: locations are nodes, walking paths are weighted undirected edges."""
from dataclasses import dataclass
from math import hypot


@dataclass(frozen=True)
class Location:
    id: str
    name: str
    x: float  # metres
    y: float  # metres


class CampusGraph:
    def __init__(self):
        self.nodes = {}      # id -> Location
        self.adjacency = {}  # id -> list of (neighbour_id, distance_in_metres)

    def add_location(self, node_id, name, x, y):
        self.nodes[node_id] = Location(node_id, name, float(x), float(y))
        self.adjacency.setdefault(node_id, [])

    def straight_line(self, a, b):
        """Straight-line (Euclidean) distance in metres. Used as the A* heuristic."""
        na, nb = self.nodes[a], self.nodes[b]
        return hypot(na.x - nb.x, na.y - nb.y)

    def add_path(self, a, b, distance):
        """Add a two-way walking path. A path can never be shorter than the straight
        line between its ends, so we reject such input; this is what makes the
        straight-line heuristic admissible (it never over-estimates)."""
        if distance + 1e-9 < self.straight_line(a, b):
            raise ValueError(f"Path {a}-{b} is shorter than the straight-line distance")
        self.adjacency[a].append((b, float(distance)))
        self.adjacency[b].append((a, float(distance)))

    def heuristic(self, a, b):
        return self.straight_line(a, b)

    def path_distance(self, path):
        total = 0.0
        for a, b in zip(path, path[1:]):
            total += next(w for n, w in self.adjacency[a] if n == b)
        return total

    def edge_count(self):
        return sum(len(v) for v in self.adjacency.values()) // 2

    def largest_component(self):
        """Ids of the biggest connected group (simple BFS flood fill)."""
        seen, best = set(), []
        for s in self.nodes:
            if s in seen:
                continue
            comp, queue = [s], [s]
            seen.add(s)
            while queue:
                u = queue.pop()
                for v, _ in self.adjacency[u]:
                    if v not in seen:
                        seen.add(v); comp.append(v); queue.append(v)
            if len(comp) > len(best):
                best = comp
        return best

    def to_dict(self):
        return {
            "nodes": [vars(n) for n in self.nodes.values()],
            "edges": [{"from": a, "to": b, "weight": w}
                      for a, nbrs in self.adjacency.items() for b, w in nbrs if a < b],
        }
