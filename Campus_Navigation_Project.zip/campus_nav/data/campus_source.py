"""One-off helper that writes data/campus.json from the hand-entered list below.
Coordinates are in metres on a 700 x 440 sketch map. Replace with your own campus
measurements if you want to model a real campus. Edge weight = walking distance in
metres = ceil(straight-line distance x path factor), path factor in {1.0..1.3}
(footpaths are never shorter than the straight line, which keeps A* admissible)."""
import json, math
from pathlib import Path

PLACES = [  # id, name, x, y
    ("GATE", "Main Gate", 40, 225), ("BUS", "Bus Stop", 60, 120), ("MED", "Medical Centre", 115, 165),
    ("PARK", "Parking Area", 110, 335), ("BANK", "Bank and ATM", 150, 285), ("ADMIN", "Admin Block", 195, 225),
    ("SEM", "Seminar Hall", 175, 70), ("AUD", "Auditorium", 270, 60), ("LIB", "Central Library", 305, 165),
    ("CANT", "Canteen", 315, 255), ("GARD", "Garden", 235, 310), ("CIV", "Civil Dept", 255, 395),
    ("MECH", "Mechanical Dept", 345, 345), ("ELE", "Electrical Dept", 410, 265), ("CSD", "Computer Dept", 420, 115),
    ("ITD", "IT Dept", 490, 190), ("LAB", "Research Labs", 530, 80), ("MESS", "Hostel Mess", 575, 175),
    ("HOSB", "Boys Hostel", 640, 100), ("HOSG", "Girls Hostel", 650, 255), ("GYM", "Gym", 545, 315),
    ("WORK", "Workshop", 450, 395), ("SPORT", "Sports Ground", 590, 395), ("QUART", "Faculty Quarters", 675, 350),
]
LINKS = [
    ("GATE", "BUS"), ("GATE", "PARK"), ("GATE", "ADMIN"), ("GATE", "MED"), ("BUS", "MED"), ("BUS", "SEM"),
    ("MED", "ADMIN"), ("PARK", "BANK"), ("PARK", "CIV"), ("ADMIN", "BANK"), ("ADMIN", "LIB"), ("ADMIN", "CANT"),
    ("ADMIN", "SEM"), ("SEM", "AUD"), ("AUD", "LIB"), ("AUD", "CSD"), ("LIB", "CSD"), ("LIB", "CANT"),
    ("CSD", "ITD"), ("CSD", "LAB"), ("ITD", "ELE"), ("ITD", "MESS"), ("ITD", "LAB"), ("ELE", "CANT"),
    ("ELE", "MECH"), ("ELE", "GYM"), ("CANT", "GARD"), ("GARD", "BANK"), ("GARD", "MECH"), ("GARD", "CIV"),
    ("MECH", "CIV"), ("MECH", "WORK"), ("WORK", "SPORT"), ("WORK", "GYM"), ("GYM", "SPORT"), ("GYM", "HOSG"),
    ("MESS", "HOSB"), ("MESS", "HOSG"), ("HOSB", "LAB"), ("HOSG", "QUART"), ("SPORT", "QUART"),
]
pos = {p[0]: (p[2], p[3]) for p in PLACES}
edges = []
for i, (a, b) in enumerate(LINKS):
    straight = math.dist(pos[a], pos[b])
    factor = 1.0 + 0.1 * ((i * 3) % 4)
    edges.append({"from": a, "to": b, "weight": math.ceil(straight * factor)})
out = {"name": "Sample Campus", "nodes": [{"id": i, "name": n, "x": x, "y": y} for i, n, x, y in PLACES], "edges": edges}
Path(__file__).with_name("campus.json").write_text(json.dumps(out, indent=1))
print(len(PLACES), "places,", len(edges), "paths")
