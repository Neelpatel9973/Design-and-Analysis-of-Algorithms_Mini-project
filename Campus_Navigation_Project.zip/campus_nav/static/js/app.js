// Front-end: loads a campus graph, asks the Flask API for all four routes, draws them.
const COLORS = {"BFS": "#2a78d6", "DFS": "#eb6834", "Dijkstra": "#1baf7a", "A*": "#e87ba4"};
// Different line styles so routes that overlap (Dijkstra and A* often do) stay visible.
const STYLE = {"BFS": {w: 11, dash: ""}, "DFS": {w: 8, dash: "14 8"}, "Dijkstra": {w: 6, dash: ""}, "A*": {w: 3, dash: "3 6"}};
const $ = id => document.getElementById(id);
const svg = $("map");
let network = null, byId = {}, results = [], hidden = new Set(), selected = null;

const W = 800, H = 520, PAD = 46;
function project() {
  const xs = network.nodes.map(n => n.x), ys = network.nodes.map(n => n.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const s = Math.min((W - 2 * PAD) / (maxX - minX || 1), (H - 2 * PAD) / (maxY - minY || 1));
  const ox = (W - s * (maxX - minX)) / 2 - s * minX, oy = (H - s * (maxY - minY)) / 2 - s * minY;
  network.nodes.forEach(n => { n.px = ox + s * n.x; n.py = oy + s * n.y; });
}
function el(tag, attrs, text) {
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (text !== undefined) e.textContent = text;
  return e;
}
function fmt(v, d = 0) { return v == null ? "-" : Number(v).toFixed(d); }

function draw() {
  svg.innerHTML = "";
  const small = network.nodes.length <= 30, tiny = network.nodes.length > 150;
  network.edges.forEach(e => {
    const a = byId[e.from], b = byId[e.to];
    svg.appendChild(el("line", {x1: a.px, y1: a.py, x2: b.px, y2: b.py, class: "edge", "stroke-width": tiny ? 1 : 2}));
    if (small) svg.appendChild(el("text", {x: (a.px + b.px) / 2, y: (a.py + b.py) / 2, class: "ewt", "text-anchor": "middle"}, e.weight));
  });
  if (selected) {                       // halo on every place the selected algorithm explored
    const r = results.find(r => r.algorithm === selected);
    if (r) r.explored.forEach(id => svg.appendChild(el("circle", {cx: byId[id].px, cy: byId[id].py, r: tiny ? 5 : 15, class: "explored", style: `--c:${COLORS[selected]}`})));
  }
  results.forEach(r => {
    if (!r.found || hidden.has(r.algorithm)) return;
    const pts = r.path.map(id => `${byId[id].px},${byId[id].py}`).join(" ");
    svg.appendChild(el("polyline", {points: pts, fill: "none", stroke: COLORS[r.algorithm], "stroke-width": STYLE[r.algorithm].w,
      "stroke-dasharray": STYLE[r.algorithm].dash, "stroke-linecap": "round", "stroke-linejoin": "round", opacity: .9}));
  });
  network.nodes.forEach(n => svg.appendChild(el("circle", {cx: n.px, cy: n.py, r: tiny ? 2.5 : 6, class: "node" + (tiny ? " tiny" : "")})));
  const s = byId[$("start").value], g = byId[$("goal").value];
  if (s) svg.appendChild(el("circle", {cx: s.px, cy: s.py, r: 9, class: "endpoint-s"}));
  if (g) svg.appendChild(el("circle", {cx: g.px, cy: g.py, r: 9, class: "endpoint-g"}));
  if (small) network.nodes.forEach(n => svg.appendChild(el("text", {x: n.px, y: n.py - 12, class: "lbl", "text-anchor": "middle"}, n.name)));
  else [s, g].forEach((n, i) => n && svg.appendChild(el("text", {x: n.px, y: n.py - 14, class: "lbl", "text-anchor": "middle"}, (i ? "Destination " : "Start ") + n.name)));
}

function fillSelects() {
  ["start", "goal"].forEach(id => {
    $(id).innerHTML = "";
    network.nodes.forEach(n => $(id).add(new Option(n.name === n.id ? n.id : `${n.name}`, n.id)));
  });
  $("start").value = network.default_start; $("goal").value = network.default_goal;
}

function buildLegend() {
  const ul = $("legend"); ul.innerHTML = "";
  Object.keys(COLORS).forEach(name => {
    const li = document.createElement("li");
    li.innerHTML = `<svg viewBox="0 0 42 12"><line x1="2" y1="6" x2="40" y2="6" stroke="${COLORS[name]}" stroke-width="${Math.min(STYLE[name].w, 8)}" stroke-dasharray="${STYLE[name].dash}" stroke-linecap="round"/></svg><span>${name}</span>`;
    li.classList.toggle("off", hidden.has(name));
    li.onclick = () => { hidden.has(name) ? hidden.delete(name) : hidden.add(name); buildLegend(); draw(); };
    ul.appendChild(li);
  });
}

async function loadScenario() {
  const sc = $("scenario");
  network = await fetch(`/api/network?scenario=${sc.value}`).then(r => r.json());
  byId = {}; network.nodes.forEach(n => byId[n.id] = n);
  project(); fillSelects(); results = []; selected = null;
  $("cards").innerHTML = ""; $("summary").hidden = true; $("tablewrap").hidden = true;
  $("map-title").textContent = sc.options[sc.selectedIndex].text;
  $("map-count").textContent = `${network.nodes.length} locations, ${network.edges.length} paths` + (network.nodes.length <= 30 ? " (numbers are metres)" : "");
  $("status").textContent = "Pick two places and press the button.";
  buildLegend(); draw();
}

async function runAll() {
  $("status").textContent = "Running...";
  const resp = await fetch("/api/route", {method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({scenario: $("scenario").value, start: $("start").value, goal: $("goal").value})});
  const data = await resp.json();
  if (!resp.ok) { $("status").textContent = data.error; return; }
  results = data.results; selected = null;
  $("status").textContent = "Done. All four algorithms were run on this trip.";
  render(); draw();
}

function render() {
  const dij = results.find(r => r.algorithm === "Dijkstra"), ast = results.find(r => r.algorithm === "A*");
  const bfs = results.find(r => r.algorithm === "BFS"), dfs = results.find(r => r.algorithm === "DFS");
  const cards = $("cards"); cards.innerHTML = "";
  results.forEach(r => {
    const d = document.createElement("div"); d.className = "card" + (selected === r.algorithm ? " sel" : "");
    d.style.setProperty("--c", COLORS[r.algorithm]);
    const names = r.path.map(id => byId[id].name === byId[id].id ? id : byId[id].name).join(" → ");
    d.innerHTML = `<h3>${r.algorithm}<span class="tag">${r.guarantee}</span></h3>
      <div class="metrics">
        <div><b>${r.found ? fmt(r.cost) + " m" : "no path"}</b><span>route distance</span></div>
        <div><b>${fmt(r.hops)}</b><span>hops (paths walked)</span></div>
        <div><b>${r.nodes_explored}</b><span>places explored</span></div>
        <div><b>${fmt(r.time_ms, 3)} ms</b><span>search time</span></div>
      </div><div class="route">${r.path.length <= 14 ? names : r.path.length + " places on route"}</div>`;
    d.onclick = () => { selected = selected === r.algorithm ? null : r.algorithm; render(); draw(); };
    cards.appendChild(d);
  });
  const tb = $("table").querySelector("tbody"); tb.innerHTML = "";
  results.forEach(r => tb.insertAdjacentHTML("beforeend", `<tr><td><b style="color:${COLORS[r.algorithm]}">&#9632;</b> ${r.algorithm}</td>
    <td>${r.found ? fmt(r.cost) + " m" : "-"}</td><td>${fmt(r.hops)}</td><td>${r.nodes_explored}</td><td>${r.max_frontier}</td><td>${fmt(r.time_ms, 3)} ms</td><td>${r.guarantee}</td></tr>`));
  $("tablewrap").hidden = false;
  const s = $("summary"); s.hidden = false;
  if (!dij.found) { s.innerHTML = "<p><b>No route exists</b> between these two places.</p>"; return; }
  const lines = [];
  lines.push(`<p><b>Shortest route: ${fmt(dij.cost)} m.</b> Dijkstra and A* both find it${Math.abs(dij.cost - ast.cost) < 1e-6 ? " (same distance, as expected)." : "."}</p>`);
  lines.push(`<p>A* explored <b>${ast.nodes_explored}</b> places versus <b>${dij.nodes_explored}</b> for Dijkstra${ast.nodes_explored < dij.nodes_explored ? ` (${dij.nodes_explored - ast.nodes_explored} fewer, because the straight-line heuristic steers it toward the destination).` : " (no saving on this trip)."}</p>`);
  const extraB = bfs.cost - dij.cost, extraD = dfs.cost - dij.cost;
  lines.push(`<p>BFS used the fewest hops (${bfs.hops}) but its route is ${extraB > 0.5 ? fmt(extraB) + " m longer" : "equally short"}. DFS found a route ${extraD > 0.5 ? fmt(extraD) + " m longer (" + (dfs.cost / dij.cost).toFixed(1) + "x)" : "of equal length"} than the shortest.</p>`);
  s.innerHTML = lines.join("");
}

$("scenario").onchange = loadScenario;
$("run").onclick = runAll;
$("swap").onclick = () => { const t = $("start").value; $("start").value = $("goal").value; $("goal").value = t; results = []; selected = null; draw(); };
$("start").onchange = $("goal").onchange = () => { draw(); };
loadScenario();
